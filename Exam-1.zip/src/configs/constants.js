const JWT_SECRET = 'BSAGCS76SAOHBH7Q2iuasuodgh8pw7q1e12eads';

module.exports = { JWT_SECRET };